 @extends(@Auth::user()->role=='admin' ? 'layouts.gentella':'layouts.'.env('LAYOUT'))
@section('content')
    <?php
    $now = date('y-m-d H:i:s');
    $deadline = \Carbon\Carbon::createFromTimestamp(strtotime($order->deadline));
    $assigns = $order->assigns()->get();
            $assign_ids = [];

     foreach($assigns as $assign){
         $assign_ids[] = $assign->id;
     }

    ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="panel-title">
                <strong>Order Topic: </strong>{{ $order->topic }}
            </div>
        </div>
        <div class="panel-body">
            <h2>Order Details</h2>
            <ul class="nav nav-tabs">
                <li class="active"><a class="btn btn-info" data-toggle="tab" href="#o_order">Order</a></li>
                {{--<li><a data-toggle="tab" href="#o_bids">Bids<span class="badge">{{ count($order->bids) }}</span> </a></li>--}}
                <li><a class="btn btn-success" data-toggle="tab" href="#o_files">Files<span class="badge">{{ $order->files()->where([
                    ['allow_client','=',1]
                ])->count()+\App\File::whereIn('assign_id',$assign_ids)->where([
                    ['allow_client','=',1]
                ])->count() }}</span></a></li>
                <li><a class="btn btn-primary" data-toggle="tab" onclick="markRead();" href="#o_messages">Messages<span class="badge">{{ $order->messages()->where([
                ['seen','=',0],
                ['sender','=',1]
                ])->count() }}</span></a></li>
            </ul>


            <div class="tab-content">

                @if($order->status == 4)
                    <div class="alert alert-info">
                        You have not approved this order. Please click the link below to approve and rate our writer.<br/>
                        <a class="btn btn-warning btn-xs" href="{{ URL::to('stud/approve/'.''.$order->id) }}"><i class="fa fa-thumbs-up"></i> Approve Now</a>

                    </div>
                @endif
                @include('client.includes.order')
                {{--@include('client.includes.bids')--}}
                @include('client.includes.messages')
                @include('client.includes.files')
            </div>
        </div>
    </div>
@endsection